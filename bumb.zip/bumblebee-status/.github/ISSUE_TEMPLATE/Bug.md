---
name: Bug Report
about: Something doesn't work as expected
title: ''
labels: ''
assignees: ''

---

### Bug Report

#### Description
Affected module: <module name>
Version used: <e.g. latest git, AUR, PIP>

<description>

#### How to reproduce
<!-- Please provide steps on how to reproduce the issue (screenshots would be great) -->

<!--
If you are having problems with fonts, please read:
https://github.com/tobi-wan-kenobi/bumblebee-status/issues/228
https://github.com/tobi-wan-kenobi/bumblebee-status/issues/210
https://github.com/tobi-wan-kenobi/bumblebee-status/issues/197
https://github.com/tobi-wan-kenobi/bumblebee-status/issues/233

Please note FontAwesome 5 is currently not supported:
https://github.com/tobi-wan-kenobi/bumblebee-status/issues/239
-->
